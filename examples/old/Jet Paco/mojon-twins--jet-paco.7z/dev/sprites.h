// Sprites.h
// Generado por SprCnv de la Churrera
// Copyleft 2010 The Mojon Twins
 
extern unsigned char sprite_1_a []; 
extern unsigned char sprite_1_b []; 
extern unsigned char sprite_1_c []; 
extern unsigned char sprite_2_a []; 
extern unsigned char sprite_2_b []; 
extern unsigned char sprite_2_c []; 
extern unsigned char sprite_3_a []; 
extern unsigned char sprite_3_b []; 
extern unsigned char sprite_3_c []; 
extern unsigned char sprite_4_a []; 
extern unsigned char sprite_4_b []; 
extern unsigned char sprite_4_c []; 
extern unsigned char sprite_5_a []; 
extern unsigned char sprite_5_b []; 
extern unsigned char sprite_5_c []; 
extern unsigned char sprite_6_a []; 
extern unsigned char sprite_6_b []; 
extern unsigned char sprite_6_c []; 
extern unsigned char sprite_7_a []; 
extern unsigned char sprite_7_b []; 
extern unsigned char sprite_7_c []; 
extern unsigned char sprite_8_a []; 
extern unsigned char sprite_8_b []; 
extern unsigned char sprite_8_c []; 
extern unsigned char sprite_9_a []; 
extern unsigned char sprite_9_b []; 
extern unsigned char sprite_9_c []; 
extern unsigned char sprite_10_a []; 
extern unsigned char sprite_10_b []; 
extern unsigned char sprite_10_c []; 
extern unsigned char sprite_11_a []; 
extern unsigned char sprite_11_b []; 
extern unsigned char sprite_11_c []; 
extern unsigned char sprite_12_a []; 
extern unsigned char sprite_12_b []; 
extern unsigned char sprite_12_c []; 
extern unsigned char sprite_13_a []; 
extern unsigned char sprite_13_b []; 
extern unsigned char sprite_13_c []; 
extern unsigned char sprite_14_a []; 
extern unsigned char sprite_14_b []; 
extern unsigned char sprite_14_c []; 
extern unsigned char sprite_15_a []; 
extern unsigned char sprite_15_b []; 
extern unsigned char sprite_15_c []; 
extern unsigned char sprite_16_a []; 
extern unsigned char sprite_16_b []; 
extern unsigned char sprite_16_c []; 
 
#asm
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_a
        defb 0, 240
        defb 3, 224
        defb 6, 192
        defb 13, 192
        defb 11, 192
        defb 11, 192
        defb 15, 128
        defb 3, 0
        defb 60, 0
        defb 127, 0
        defb 103, 0
        defb 7, 0
        defb 3, 0
        defb 126, 0
        defb 124, 0
        defb 64, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_b
        defb 0, 15
        defb 224, 7
        defb 0, 3
        defb 16, 3
        defb 80, 3
        defb 80, 3
        defb 240, 3
        defb 224, 1
        defb 24, 0
        defb 252, 0
        defb 236, 0
        defb 226, 0
        defb 214, 0
        defb 46, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_a
        defb 3, 224
        defb 6, 192
        defb 13, 192
        defb 11, 192
        defb 11, 192
        defb 15, 192
        defb 3, 192
        defb 12, 128
        defb 31, 0
        defb 55, 0
        defb 55, 0
        defb 54, 0
        defb 6, 0
        defb 6, 224
        defb 6, 224
        defb 7, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_b
        defb 224, 7
        defb 0, 3
        defb 16, 3
        defb 80, 3
        defb 80, 3
        defb 240, 3
        defb 224, 3
        defb 16, 3
        defb 248, 1
        defb 232, 1
        defb 232, 1
        defb 200, 1
        defb 96, 1
        defb 96, 7
        defb 96, 7
        defb 112, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_a
        defb 0, 240
        defb 3, 224
        defb 6, 192
        defb 13, 192
        defb 11, 192
        defb 11, 192
        defb 15, 192
        defb 3, 192
        defb 12, 192
        defb 15, 192
        defb 7, 192
        defb 8, 128
        defb 23, 0
        defb 43, 0
        defb 48, 0
        defb 32, 2
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_b
        defb 0, 15
        defb 224, 7
        defb 0, 3
        defb 16, 3
        defb 80, 3
        defb 80, 3
        defb 240, 3
        defb 224, 3
        defb 16, 3
        defb 176, 3
        defb 176, 3
        defb 96, 0
        defb 228, 0
        defb 252, 0
        defb 124, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_a
        defb 0, 240
        defb 3, 224
        defb 6, 192
        defb 13, 192
        defb 11, 192
        defb 11, 192
        defb 15, 192
        defb 3, 192
        defb 12, 0
        defb 127, 0
        defb 103, 0
        defb 7, 0
        defb 31, 128
        defb 56, 0
        defb 48, 1
        defb 0, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_b
        defb 0, 15
        defb 224, 7
        defb 0, 3
        defb 16, 3
        defb 80, 3
        defb 80, 3
        defb 240, 3
        defb 224, 3
        defb 16, 0
        defb 254, 0
        defb 230, 0
        defb 224, 0
        defb 248, 1
        defb 28, 0
        defb 12, 128
        defb 0, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_a
        defb 0, 240
        defb 7, 224
        defb 0, 192
        defb 8, 192
        defb 10, 192
        defb 10, 192
        defb 15, 192
        defb 7, 128
        defb 24, 0
        defb 63, 0
        defb 55, 0
        defb 71, 0
        defb 107, 0
        defb 116, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_b
        defb 0, 15
        defb 192, 7
        defb 96, 3
        defb 176, 3
        defb 208, 3
        defb 208, 3
        defb 240, 1
        defb 192, 0
        defb 60, 0
        defb 254, 0
        defb 230, 0
        defb 224, 0
        defb 192, 0
        defb 126, 0
        defb 62, 0
        defb 2, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_a
        defb 7, 224
        defb 0, 192
        defb 8, 192
        defb 10, 192
        defb 10, 192
        defb 15, 192
        defb 7, 192
        defb 8, 192
        defb 31, 128
        defb 23, 128
        defb 23, 128
        defb 19, 128
        defb 6, 128
        defb 6, 224
        defb 6, 224
        defb 14, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_b
        defb 192, 7
        defb 96, 3
        defb 176, 3
        defb 208, 3
        defb 208, 3
        defb 240, 3
        defb 192, 3
        defb 48, 1
        defb 248, 0
        defb 236, 0
        defb 236, 0
        defb 108, 0
        defb 96, 0
        defb 96, 7
        defb 96, 7
        defb 224, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_a
        defb 0, 240
        defb 7, 224
        defb 0, 192
        defb 8, 192
        defb 10, 192
        defb 10, 192
        defb 15, 192
        defb 7, 192
        defb 8, 192
        defb 13, 192
        defb 13, 192
        defb 6, 0
        defb 39, 0
        defb 63, 0
        defb 62, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_b
        defb 0, 15
        defb 192, 7
        defb 96, 3
        defb 176, 3
        defb 208, 3
        defb 208, 3
        defb 240, 3
        defb 192, 3
        defb 48, 3
        defb 240, 3
        defb 224, 3
        defb 16, 1
        defb 232, 0
        defb 212, 0
        defb 12, 0
        defb 4, 64
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_a
        defb 0, 240
        defb 7, 224
        defb 0, 192
        defb 8, 192
        defb 10, 192
        defb 10, 192
        defb 15, 192
        defb 7, 192
        defb 8, 0
        defb 127, 0
        defb 103, 0
        defb 7, 0
        defb 31, 128
        defb 56, 0
        defb 48, 1
        defb 0, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_b
        defb 0, 15
        defb 192, 7
        defb 96, 3
        defb 176, 3
        defb 208, 3
        defb 208, 3
        defb 240, 3
        defb 192, 3
        defb 48, 0
        defb 254, 0
        defb 230, 0
        defb 224, 0
        defb 248, 1
        defb 28, 0
        defb 12, 128
        defb 0, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_a
        defb 0, 255
        defb 0, 248
        defb 3, 240
        defb 4, 224
        defb 12, 192
        defb 31, 192
        defb 31, 128
        defb 55, 0
        defb 111, 0
        defb 87, 0
        defb 15, 0
        defb 31, 192
        defb 28, 192
        defb 30, 192
        defb 0, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_b
        defb 0, 255
        defb 0, 31
        defb 192, 15
        defb 32, 7
        defb 176, 3
        defb 248, 1
        defb 248, 1
        defb 252, 0
        defb 254, 0
        defb 250, 0
        defb 248, 0
        defb 248, 1
        defb 60, 1
        defb 0, 1
        defb 0, 127
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_a
        defb 0, 255
        defb 0, 248
        defb 3, 240
        defb 4, 224
        defb 12, 192
        defb 31, 192
        defb 31, 128
        defb 55, 0
        defb 111, 0
        defb 87, 0
        defb 15, 0
        defb 25, 192
        defb 30, 192
        defb 0, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_b
        defb 0, 255
        defb 0, 31
        defb 192, 15
        defb 32, 7
        defb 176, 3
        defb 248, 1
        defb 248, 1
        defb 252, 0
        defb 254, 0
        defb 250, 0
        defb 248, 0
        defb 248, 3
        defb 48, 1
        defb 60, 1
        defb 0, 1
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_a
        defb 0, 240
        defb 7, 192
        defb 29, 128
        defb 56, 0
        defb 102, 0
        defb 93, 0
        defb 58, 0
        defb 116, 0
        defb 52, 0
        defb 90, 0
        defb 13, 0
        defb 66, 0
        defb 40, 0
        defb 23, 128
        defb 7, 192
        defb 0, 240
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_b
        defb 0, 15
        defb 224, 3
        defb 184, 1
        defb 28, 0
        defb 102, 0
        defb 186, 0
        defb 92, 0
        defb 46, 0
        defb 44, 0
        defb 90, 0
        defb 176, 0
        defb 66, 0
        defb 20, 0
        defb 232, 1
        defb 224, 3
        defb 0, 15
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_a
        defb 0, 240
        defb 7, 192
        defb 31, 128
        defb 53, 0
        defb 127, 0
        defb 120, 0
        defb 64, 0
        defb 20, 0
        defb 52, 0
        defb 74, 0
        defb 32, 0
        defb 84, 0
        defb 40, 0
        defb 23, 128
        defb 7, 192
        defb 0, 240
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_b
        defb 0, 15
        defb 224, 3
        defb 248, 1
        defb 172, 0
        defb 254, 0
        defb 30, 0
        defb 2, 0
        defb 40, 0
        defb 44, 0
        defb 82, 0
        defb 4, 0
        defb 42, 0
        defb 20, 0
        defb 232, 1
        defb 224, 3
        defb 0, 15
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_a
        defb 0, 255
        defb 0, 248
        defb 3, 240
        defb 6, 192
        defb 31, 128
        defb 55, 0
        defb 103, 0
        defb 103, 0
        defb 103, 0
        defb 99, 0
        defb 115, 0
        defb 67, 0
        defb 3, 16
        defb 7, 240
        defb 0, 240
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_b
        defb 0, 255
        defb 0, 15
        defb 224, 7
        defb 48, 1
        defb 252, 0
        defb 118, 0
        defb 243, 0
        defb 243, 0
        defb 243, 0
        defb 99, 0
        defb 103, 0
        defb 97, 0
        defb 96, 4
        defb 112, 7
        defb 0, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_a
        defb 0, 255
        defb 0, 248
        defb 3, 240
        defb 6, 192
        defb 31, 128
        defb 55, 0
        defb 103, 0
        defb 103, 0
        defb 103, 0
        defb 99, 0
        defb 227, 8
        defb 35, 8
        defb 3, 128
        defb 7, 240
        defb 0, 240
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_b
        defb 0, 255
        defb 0, 15
        defb 224, 7
        defb 48, 1
        defb 252, 0
        defb 118, 0
        defb 243, 0
        defb 243, 0
        defb 243, 0
        defb 103, 0
        defb 99, 0
        defb 96, 8
        defb 96, 7
        defb 112, 7
        defb 0, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_a
        defb 0, 0
        defb 47, 0
        defb 95, 0
        defb 47, 0
        defb 23, 128
        defb 11, 192
        defb 5, 224
        defb 3, 240
        defb 0, 248
        defb 1, 252
        defb 1, 252
        defb 0, 254
        defb 0, 255
        defb 0, 255
        defb 0, 252
        defb 0, 254
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_b
        defb 0, 0
        defb 250, 0
        defb 244, 0
        defb 250, 0
        defb 212, 1
        defb 232, 3
        defb 208, 7
        defb 160, 15
        defb 0, 31
        defb 128, 63
        defb 192, 31
        defb 32, 15
        defb 16, 199
        defb 16, 199
        defb 32, 15
        defb 0, 31
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_a
        defb 0, 0
        defb 47, 0
        defb 95, 0
        defb 47, 0
        defb 23, 128
        defb 11, 192
        defb 5, 224
        defb 3, 240
        defb 0, 248
        defb 1, 252
        defb 0, 254
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_b
        defb 0, 0
        defb 250, 0
        defb 244, 0
        defb 250, 0
        defb 212, 1
        defb 232, 3
        defb 208, 7
        defb 160, 15
        defb 0, 31
        defb 128, 63
        defb 224, 15
        defb 16, 7
        defb 8, 227
        defb 8, 227
        defb 8, 3
        defb 0, 135
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
#endasm
 
